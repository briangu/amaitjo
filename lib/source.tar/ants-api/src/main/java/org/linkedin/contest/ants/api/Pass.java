package org.linkedin.contest.ants.api;

/*
 * Indicates that this ant wants to do nothing this turn
 */
public class Pass implements Action {
}
